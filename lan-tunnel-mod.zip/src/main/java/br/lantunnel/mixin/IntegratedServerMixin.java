package br.lantunnel.mixin;

import br.lantunnel.LanTunnelMod;
import br.lantunnel.TunnelConfig;
import net.minecraft.server.integrated.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin {

    // Forca a porta da LAN para a porta fixa do config (padrao 25565).
    @ModifyVariable(method = "openToLan", at = @At("HEAD"), argsOnly = true, require = 0)
    private int lantunnel$fixedPort(int port) {
        try {
            int fixed = TunnelConfig.load().fixedPort;
            return fixed > 0 ? fixed : port;
        } catch (Throwable t) {
            return port;
        }
    }

    // Quando o mundo abre para LAN com sucesso: libera pirata e sobe o tunel.
    @Inject(method = "openToLan", at = @At("RETURN"), require = 0)
    private void lantunnel$afterOpen(net.minecraft.world.GameMode gameMode, boolean cheats, int port,
                                     CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValue()) {
                // Desliga a verificacao de conta da Mojang (modo offline = pirata + original entram)
                ((IntegratedServer) (Object) this).setOnlineMode(false);
                int fixed = TunnelConfig.load().fixedPort;
                LanTunnelMod.onLanOpened(fixed > 0 ? fixed : port);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
