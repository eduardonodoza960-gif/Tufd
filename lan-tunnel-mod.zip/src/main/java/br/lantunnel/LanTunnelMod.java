package br.lantunnel;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LanTunnelMod implements ClientModInitializer {
    public static volatile boolean lanActive = false;
    private static BoreTunnel tunnel;

    @Override
    public void onInitializeClient() {
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> stop());
    }

    /** Pares {nome da rede, ip} das placas de rede ativas (IPv4). */
    private static List<String[]> localAddresses() {
        List<String[]> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && !a.isLinkLocalAddress()) {
                        out.add(new String[]{ni.getDisplayName(), a.getHostAddress()});
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return out;
    }

    private static Text copyable(String addr) {
        return Text.literal(addr).styled(s -> s
                .withColor(Formatting.AQUA)
                .withUnderline(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, addr))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                        Text.literal("Clique para copiar"))));
    }

    public static synchronized void onLanOpened(int localPort) {
        stop();
        lanActive = true;
        TunnelConfig cfg = TunnelConfig.load();
        List<String[]> addrs = localAddresses();

        MinecraftClient.getInstance().execute(() -> {
            try {
                chat(Text.literal("[LAN Tunnel] LAN aberta na porta " + localPort
                        + " (pirata + original liberados).").formatted(Formatting.GREEN));
                if (addrs.isEmpty()) {
                    chat(Text.literal("[LAN Tunnel] Nao achei o IP deste PC. Use ipconfig no Windows.")
                            .formatted(Formatting.RED));
                } else {
                    chat(Text.literal("[LAN Tunnel] IP:porta (clique para copiar). Mesma rede ou VPN virtual:")
                            .formatted(Formatting.GRAY));
                    for (String[] a : addrs) {
                        chat(Text.literal("  " + a[0] + ": ").formatted(Formatting.DARK_GRAY)
                                .append(copyable(a[1] + ":" + localPort)));
                    }
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });

        if (!cfg.useBore) {
            return;
        }

        final BoreTunnel tn = new BoreTunnel(cfg.host, cfg.controlPort, localPort, cfg.secret);
        tunnel = tn;
        tn.start().whenComplete((remotePort, err) -> {
            MinecraftClient.getInstance().execute(() -> {
                try {
                    if (err != null) {
                        chat(Text.literal("[LAN Tunnel] Falha ao criar link publico: " + err.getMessage())
                                .formatted(Formatting.RED));
                        return;
                    }
                    chat(Text.literal("[LAN Tunnel] Link pela internet (pirata + original): ")
                            .formatted(Formatting.GREEN)
                            .append(copyable(cfg.host + ":" + remotePort)));
                    chat(Text.literal("[LAN Tunnel] Latencia ate o servidor do tunel: " + tn.connectMs + " ms")
                            .formatted(Formatting.YELLOW));
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            });
        });
    }

    public static synchronized void stop() {
        lanActive = false;
        if (tunnel != null) {
            tunnel.stop();
            tunnel = null;
        }
    }

    private static void chat(Text t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(t);
        }
    }
}
