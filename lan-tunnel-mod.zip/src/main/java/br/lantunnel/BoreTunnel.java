package br.lantunnel;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/** Cliente minimo do protocolo "bore" (servidor publico bore.pub, sem conta). */
public class BoreTunnel {
    private final String host;
    private final int controlPort;
    private final int localPort;
    private final String secret;
    private volatile boolean running = true;
    private volatile Socket control;
    public volatile long connectMs = -1;

    public BoreTunnel(String host, int controlPort, int localPort, String secret) {
        this.host = host;
        this.controlPort = controlPort;
        this.localPort = localPort;
        this.secret = secret == null ? "" : secret;
    }

    public CompletableFuture<Integer> start() {
        CompletableFuture<Integer> future = new CompletableFuture<>();
        Thread t = new Thread(() -> run(future), "LanTunnel-control");
        t.setDaemon(true);
        t.start();
        return future;
    }

    public void stop() {
        running = false;
        close(control);
    }

    private void run(CompletableFuture<Integer> future) {
        try {
            Socket s = new Socket();
            long t0 = System.nanoTime();
            s.connect(new InetSocketAddress(host, controlPort), 10000);
            connectMs = (System.nanoTime() - t0) / 1_000_000;
            s.setTcpNoDelay(true);
            s.setSoTimeout(15000);
            control = s;
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            authenticate(in, out);
            send(out, "{\"Hello\":0}");
            JsonElement hello = JsonParser.parseString(readMessage(in));
            if (!hello.isJsonObject() || !hello.getAsJsonObject().has("Hello")) {
                throw new IOException("Resposta inesperada do servidor: " + hello);
            }
            future.complete(hello.getAsJsonObject().get("Hello").getAsInt());

            while (running) {
                JsonElement msg = JsonParser.parseString(readMessage(in));
                if (msg.isJsonObject()) {
                    JsonObject o = msg.getAsJsonObject();
                    if (o.has("Connection")) {
                        String id = o.get("Connection").getAsString();
                        Thread h = new Thread(() -> handle(id), "LanTunnel-conn");
                        h.setDaemon(true);
                        h.start();
                    } else if (o.has("Error")) {
                        throw new IOException(o.get("Error").getAsString());
                    }
                }
                // "Heartbeat" e ignorado
            }
        } catch (Exception e) {
            if (!future.isDone()) {
                future.completeExceptionally(e);
            }
        } finally {
            close(control);
        }
    }

    private void handle(String id) {
        Socket remote = null;
        Socket local = null;
        try {
            remote = new Socket();
            remote.connect(new InetSocketAddress(host, controlPort), 10000);
            remote.setSoTimeout(15000);
            authenticate(remote.getInputStream(), remote.getOutputStream());
            remote.setSoTimeout(0);
            send(remote.getOutputStream(), "{\"Accept\":\"" + id + "\"}");
            local = new Socket("127.0.0.1", localPort);
            local.setTcpNoDelay(true);
            remote.setTcpNoDelay(true);
            final Socket r = remote;
            final Socket l = local;
            Thread a = new Thread(() -> pipe(r, l), "LanTunnel-pipe-a");
            a.setDaemon(true);
            a.start();
            pipe(l, r);
        } catch (Exception ignored) {
            close(remote);
            close(local);
        }
    }

    private static void pipe(Socket from, Socket to) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            close(from);
            close(to);
        }
    }

    /** Handshake do bore quando o servidor tem senha (secret). Sem secret nao faz nada. */
    private void authenticate(InputStream in, OutputStream out) throws Exception {
        if (secret.isEmpty()) {
            return;
        }
        JsonElement ch = JsonParser.parseString(readMessage(in));
        if (!ch.isJsonObject() || !ch.getAsJsonObject().has("Challenge")) {
            throw new IOException("Servidor nao pediu autenticacao: confira o secret no config");
        }
        java.util.UUID uuid = java.util.UUID.fromString(ch.getAsJsonObject().get("Challenge").getAsString());
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(16);
        bb.putLong(uuid.getMostSignificantBits());
        bb.putLong(uuid.getLeastSignificantBits());

        byte[] key = java.security.MessageDigest.getInstance("SHA-256")
                .digest(secret.getBytes(StandardCharsets.UTF_8));
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        mac.init(new javax.crypto.spec.SecretKeySpec(key, "HmacSHA256"));
        byte[] tag = mac.doFinal(bb.array());
        StringBuilder hex = new StringBuilder();
        for (byte b : tag) {
            hex.append(String.format("%02x", b));
        }
        send(out, "{\"Authenticate\":\"" + hex + "\"}");
    }

    private static void send(OutputStream out, String json) throws IOException {
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.write(0);
        out.flush();
    }

    private static String readMessage(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == 0) {
                return bos.toString(StandardCharsets.UTF_8);
            }
            bos.write(b);
        }
        throw new IOException("Conexao fechada pelo servidor do tunel");
    }

    private static void close(Socket s) {
        if (s != null) {
            try { s.close(); } catch (IOException ignored) {}
        }
    }
}
