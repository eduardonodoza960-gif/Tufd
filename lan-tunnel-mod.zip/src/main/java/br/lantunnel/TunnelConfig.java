package br.lantunnel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Arquivo config/lantunnel.json (criado sozinho na primeira vez). */
public class TunnelConfig {
    /** Porta fixa da LAN (para o playit.gg apontar sempre pro mesmo lugar). 0 = aleatoria. */
    public int fixedPort = 0;
    /** true = tambem cria o link bore.pub; false = so abre a porta fixa (use com playit.gg). */
    public boolean useBore = true;
    public String host = "bore.pub";
    public int controlPort = 7835;
    public String secret = "";

    public static TunnelConfig load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path file = FabricLoader.getInstance().getConfigDir().resolve("lantunnel.json");
        try {
            if (Files.exists(file)) {
                TunnelConfig c = gson.fromJson(Files.readString(file), TunnelConfig.class);
                if (c != null && c.host != null && !c.host.isBlank()) {
                    if (c.secret == null) c.secret = "";
                    if (c.fixedPort != 0 && (c.fixedPort < 1024 || c.fixedPort > 65535)) c.fixedPort = 0;
                    return c;
                }
            }
            TunnelConfig def = new TunnelConfig();
            Files.writeString(file, gson.toJson(def));
            return def;
        } catch (IOException | RuntimeException e) {
            e.printStackTrace();
            return new TunnelConfig();
        }
    }
}
